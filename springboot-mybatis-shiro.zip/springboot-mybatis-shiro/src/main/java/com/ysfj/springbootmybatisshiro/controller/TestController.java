package com.ysfj.springbootmybatisshiro.controller;

import com.ysfj.springbootmybatisshiro.pojo.User;
import com.ysfj.springbootmybatisshiro.service.UserService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletRequest;

@RestController
@RequestMapping("/test")
public class TestController {

    @Autowired
    private UserService userService;

    @RequiresPermissions("system:user:add")
    @RequestMapping("/add")
    public String add(User loginUser, ServletRequest request){

        return "add";
    }

    @RequiresRoles("admin")
    @RequestMapping("/modify")
    public String modify(User loginUser,ServletRequest request){

        return "modify";
    }

    @RequiresPermissions("system:user:delete")
    @RequestMapping("/delete")
    public String delete(User loginUser,ServletRequest request){

        return "delete";
    }
}
