package com.ysfj.springbootmybatisshiro.service;

import com.ysfj.springbootmybatisshiro.pojo.Permission;



public interface PermissionService {
	
	public Permission createPermission(Permission permission);
	
	public void deletePermission(Long permissionId);
}
