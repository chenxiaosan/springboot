package com.ysfj.springbootmybatisshiro.dao;


import com.ysfj.springbootmybatisshiro.pojo.Permission;

public interface PermissionDao {

    public Permission createPermission(Permission permission);

    public void deletePermission(Long permissionId);

}
