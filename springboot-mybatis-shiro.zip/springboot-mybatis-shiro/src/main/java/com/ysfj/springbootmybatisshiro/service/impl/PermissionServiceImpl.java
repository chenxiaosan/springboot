package com.ysfj.springbootmybatisshiro.service.impl;

import com.ysfj.springbootmybatisshiro.pojo.Permission;
import com.ysfj.springbootmybatisshiro.service.PermissionService;
import org.springframework.stereotype.Service;

@Service
public class PermissionServiceImpl implements PermissionService {

	@Override
	public Permission createPermission(Permission permission) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deletePermission(Long permissionId) {
		// TODO Auto-generated method stub
		
	}
	


}
